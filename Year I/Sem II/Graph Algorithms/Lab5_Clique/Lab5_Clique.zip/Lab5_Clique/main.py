from undirectedGraph import UndirectedGraph

graph = UndirectedGraph()
graph.loadFromFile("input.txt")

graph.findMaxClique()