#pragma once

void testP6();