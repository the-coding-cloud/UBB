#pragma once

void testP10();
