module ToyLanguageInterpreterGUI {
    requires javafx.fxml;
    requires javafx.controls;

    opens GUI;

}